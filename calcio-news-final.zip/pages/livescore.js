export default function Livescore() {
  return (
    <div className="min-h-screen p-4 bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">Livescore</h1>
      <p>Risultati delle partite in tempo reale saranno disponibili qui.</p>
    </div>
  );
}
